package com.cafe.servlet;

import com.cafe.dao.OrderDAO;
import com.cafe.model.Order;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/addOrder")
public class AddOrderServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String customerName = request.getParameter("customerName");
        String[] productNames = request.getParameterValues("productName");
        int quantity = Integer.parseInt(request.getParameter("quantity"));

        OrderDAO dao = new OrderDAO();
        boolean success = true;

        for (String product : productNames) {
            Order order = new Order();
            order.setCustomerName(customerName);
            order.setProductName(product);
            order.setQuantity(quantity);

            if (!dao.insertOrder(order)) {
                success = false;
            }
        }

        if (success) {
            request.getSession().removeAttribute("cart"); // Clear cart
            response.sendRedirect("orders"); // Redirect to order view
        } else {
            response.getWriter().println("❌ Failed to insert one or more orders.");
        }
    }
}